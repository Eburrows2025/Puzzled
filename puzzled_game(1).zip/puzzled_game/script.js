
const lobbyScreen = document.getElementById('lobby-screen');
const gameScreen = document.getElementById('game-screen');
const statsScreen = document.getElementById('stats-screen');
const playBtn = document.getElementById('play-btn');
const submitBtn = document.getElementById('submit-btn');
const backBtn = document.getElementById('back-btn');
const puzzleQuestion = document.getElementById('puzzle-question');
const answerInput = document.getElementById('answer-input');
const feedback = document.getElementById('feedback');
const streakText = document.getElementById('streak');
const triesText = document.getElementById('tries');

const puzzles = {
  1: { type: "anagram", question: "Unscramble: LPAEP", answer: "APPLE" },
  2: { type: "mastermind", question: "Code with two digits, each 1-3", answer: "11" },
  3: { type: "riddle", question: "I speak without a mouth and hear without ears. What am I?", answer: "ECHO" },
  4: { type: "visual", question: "What shape comes next: ◼ ◻ ◼ ◻ ?", answer: "◼" },
  5: { type: "sequence", question: "What comes next: 2, 4, 8, 16, ?", answer: "32" },
  6: { type: "cipher", question: "Decode: Uifsf jt b tfdsfu nfttbhf", answer: "THERE IS A SECRET MESSAGE" },
  0: { type: "mystery", question: "You see me once in a minute, twice in a moment...", answer: "M" },
};

const today = new Date().getDay();
const todaysPuzzle = puzzles[today];
let tries = Number(localStorage.getItem("tries") || 0);
let streak = Number(localStorage.getItem("streak") || 0);

playBtn.onclick = () => {
  lobbyScreen.classList.remove('active');
  gameScreen.classList.add('active');
  puzzleQuestion.textContent = todaysPuzzle.question;
  feedback.textContent = '';
};

submitBtn.onclick = () => {
  const guess = answerInput.value.trim().toUpperCase();
  if (!guess) return;
  tries++;
  localStorage.setItem("tries", tries);
  if (guess === todaysPuzzle.answer) {
    feedback.textContent = "Correct!";
    streak++;
    localStorage.setItem("streak", streak);
    setTimeout(showStats, 1000);
  } else if (tries >= 5) {
    feedback.textContent = "Out of tries! Answer was: " + todaysPuzzle.answer;
    streak = 0;
    localStorage.setItem("streak", streak);
    setTimeout(showStats, 1000);
  } else {
    feedback.textContent = "Try again.";
  }
  answerInput.value = "";
};

backBtn.onclick = () => {
  statsScreen.classList.remove('active');
  lobbyScreen.classList.add('active');
};

function showStats() {
  gameScreen.classList.remove('active');
  statsScreen.classList.add('active');
  streakText.textContent = "Streak: " + streak;
  triesText.textContent = "Tries today: " + tries;
}
